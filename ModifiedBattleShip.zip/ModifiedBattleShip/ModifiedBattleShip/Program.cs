﻿using ModifiedBattleShip;


Game game = new Game();
game.RunGame();



